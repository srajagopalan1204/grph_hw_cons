"""
Consolidate multi-Cono weekly ERP training reports.
- Parses config.json5 (allows comments, so Cono2 can be toggled on/off easily).
- Generates output with 24-hour timestamp format: Consolidate_report_MMDDYYYY_HH_MM.xlsx
"""

import os
import pandas as pd
from datetime import datetime
import json5

def load_config(config_path="config.json5"):
    """Load configuration with JSON5 parser."""
    with open(config_path, "r") as f:
        return json5.load(f)

def consolidate_reports():
    config = load_config()

    for cono, details in config.items():
        source_path = details["source_path"]
        destination_path = details["destination_path"]
        files = details["files"]

        # Create destination directory if not exists
        os.makedirs(destination_path, exist_ok=True)

        # Generate timestamped filename
        timestamp = datetime.now().strftime("%m%d%Y_%H_%M")
        output_filename = f"Consolidate_report_{timestamp}.xlsx"
        output_path = os.path.join(destination_path, output_filename)

        # Placeholder logic: combine input Excel files
        combined = []
        for section, mapping in files.items():
            section_path = os.path.join(source_path, section)
            if os.path.exists(section_path):
                try:
                    df = pd.read_excel(section_path)
                    df["Source_Section"] = section
                    combined.append(df)
                except Exception as e:
                    print(f"Error reading {section_path}: {e}")

        if combined:
            final_df = pd.concat(combined, ignore_index=True)
            final_df.to_excel(output_path, index=False)
            print(f"Consolidated report created: {output_path}")
        else:
            print(f"No data consolidated for {cono}.")

if __name__ == "__main__":
    consolidate_reports()

# Multi-Cono Consolidation (JSON5 Version)

## Overview
This script consolidates weekly ERP training reports from multiple Conos into a timestamped Excel report.

### Key Features
- Supports multiple Conos (`Cono1`, `Cono3`).
- Uses `config.json5` (allows comments for toggling Cono2).
- Output file named as `Consolidate_report_MMDDYYYY_HH_MM.xlsx` (24-hour format).

## Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Paths
Edit `config.json5` to point to your source/destination folders.

### 3. Toggle Cono2
To enable Cono2:
- Remove `//` comment lines from the `Cono2` block in `config.json5`.

To disable Cono2:
- Add `//` in front of the `Cono2` block lines.

### 4. Run Script
```bash
python consolidate_reports.py
```

Output will be saved in the specified `Consolidated_reports` folder for each Cono.
